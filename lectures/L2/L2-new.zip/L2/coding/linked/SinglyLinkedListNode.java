public class SinglyLinkedListNode { 

      public int value; 

      public SinglyLinkedListNode next; 

 

      public SinglyLinkedListNode(int value) { 

            this.value = value; 

            next = null; 

      } 

} 
