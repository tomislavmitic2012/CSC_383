public class SinglyLinkedListNode<T> { 

      public T value; 

      public SinglyLinkedListNode <T> next; 

 

      public SinglyLinkedListNode(T value) { 

            this.value = value; 

            next = null; 

      } 

} 
